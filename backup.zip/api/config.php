<?php
/* =============================================================
   CONFIG  --  this is the only file you need to edit
   ============================================================= */

/* ---------- 1) ADMIN LOGIN ---------- */
/* These credentials are used to sign in at /admin */
define('ADMIN_EMAIL',    'ausafahmed824@gmail.com');
define('ADMIN_PASSWORD', 'Ausaf427722');   // <-- change this

/* ---------- 2) DATABASE (MySQL) ---------- */
/* Laragon defaults: user "root" with an empty password.
   On live hosting, use the credentials from your cPanel. */
define('DB_HOST', '127.0.0.1');
define('DB_PORT', 3306);
define('DB_NAME', 'portfolio');
define('DB_USER', 'root');
define('DB_PASS', '');

/* ---------- 3) EMAIL (SMTP) ---------- */
/* For Gmail: turn on 2-Step Verification in your Google account,
   then create a 16-digit "App Password" at myaccount.google.com/apppasswords
   and paste it into SMTP_PASS (not your regular Gmail password). */
define('SMTP_ENABLED', true);   // false = no email; messages are only stored in the admin panel

define('SMTP_HOST',   'smtp.gmail.com');
define('SMTP_PORT',   587);          // 587 = tls  |  465 = ssl
define('SMTP_SECURE', 'tls');        // 'tls' or 'ssl'
define('SMTP_USER',   'ausafahmed824@gmail.com');   // <-- your email
define('SMTP_PASS',   '');                          // <-- app password goes here

/* Where contact messages are delivered */
define('MAIL_TO',        'ausafahmed824@gmail.com');
define('MAIL_FROM',      SMTP_USER);       // for Gmail this must stay as SMTP_USER
define('MAIL_FROM_NAME', 'Portfolio Website');

/* Verify the TLS certificate?  true = secure (recommended).
   If you hit an "SSL/TLS" error on localhost/XAMPP, set this to false. */
define('SMTP_VERIFY_CERT', true);

/* ---------- 4) UPLOADS ---------- */
define('MAX_UPLOAD_BYTES', 4 * 1024 * 1024);   // 4 MB

/* =============================================================
   Nothing below this line needs to be changed
   ============================================================= */
define('BASE_DIR', dirname(__DIR__));

/* Legacy JSON files -- only read once by install.php to migrate
   the old data into MySQL. Safe to delete afterwards. */
define('DATA_FILE',     BASE_DIR . '/data/projects.json');
define('MESSAGES_FILE', BASE_DIR . '/data/messages.json');
