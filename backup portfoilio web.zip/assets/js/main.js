function openProjects(evt, projectName) {
  var i, tabcontent, tablinks;

  tabcontent = document.getElementsByClassName("tabcontent");
  for (i = 0; i < tabcontent.length; i++) {
    tabcontent[i].classList.remove("active");
  }

  tablinks = document.getElementsByClassName("tablinks");
  for (i = 0; i < tablinks.length; i++) {
    tablinks[i].classList.remove("active");
  }

  var currentTab = document.getElementById(projectName);
  currentTab.classList.add("active");

  evt.currentTarget.classList.add("active");
}

document.addEventListener("DOMContentLoaded", function () {
  var firstTab = document.querySelector(".tablinks");
  if (firstTab) {
    firstTab.click();
  }
});